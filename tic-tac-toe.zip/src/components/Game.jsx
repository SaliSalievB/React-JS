import React, { Component } from 'react';
import Board from './Board';

export class Game extends Component {
  constructor(props){
    super(props);
    this.state = {
      history: [{
        squares: Array(0).fill(null)
      }]
    }
  }
    render() {
        return (
          
            <div className="game">
                <div className="game-board">
                  <center>
                    { <Board /> }
                    </center>
                </div>
                <div className="game-info">
                  <center>
                    <div>{/* status */}</div>
                    <ol>{/* TODO */}</ol>
                    </center>
                </div>
            </div>
        );
    }
}
export default Game