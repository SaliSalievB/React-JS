import React, { useState } from "react";
import ToDoItem from "./ToDoItem";
import "./App.css";
import "./DarkMode.css";

function App() {
  const [task, setTask] = useState("");
  const [items, setItems] = useState([]);
  const [theme, setTheme] = useState("light");

  function handleChange(event) {
    const newValue = event.target.value;
    setTask(newValue);
  }

  function addTask() {
    if (!task) {
      return window.alert("Your task is empty");
    }
    setItems(prevValues => {
      return [...prevValues, task];
    });
    setTask("");
  }


  function deleteItem(id) {
    setItems(prevValues => {
      return prevValues.filter((item, index) => {
        return index !== id;
      });
    });
  }

  function toggleTheme() {
    setTheme(prevTheme => {
      return prevTheme === "light" ? "dark" : "light";
    });
  }

  return (
    <center>
    <div className={`container ${theme}`}>
      <div className="heading">
        <h1>To-Do List</h1>
        <button onClick={toggleTheme}>Toggle Dark Mode</button>
      </div>
      <div className="form">
        <input
          name="taskInput"
          type="text"
          onChange={handleChange}
          value={task}
        />
        <button onClick={addTask}>
          <span>ADD</span>
        </button>
      </div>
      <div>
        <ul>
          {items.map((item, index) => (
            <ToDoItem
              key={index}
              id={index}
              text={item}
              onChecked={deleteItem}
            />
          ))}
        </ul>
      </div>
    </div>
    </center>
  );
}

export default App;
